g++ -O2 -std=c++17 -pthread -o a.out main.cpp MovieCatalog.cpp
./a.out